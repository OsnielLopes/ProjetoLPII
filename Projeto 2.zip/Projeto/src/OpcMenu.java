public enum OpcMenu {
    pesquisar, gravarArquivo, sair;
}
