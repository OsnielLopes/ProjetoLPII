public enum Filtro {
    time, cidade, estado, mes;
}
