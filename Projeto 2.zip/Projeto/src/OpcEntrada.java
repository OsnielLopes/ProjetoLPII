
public enum OpcEntrada {
    Console, Arquivo;
}
